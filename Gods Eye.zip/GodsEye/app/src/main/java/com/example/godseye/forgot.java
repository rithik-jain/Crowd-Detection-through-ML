package com.example.godseye;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;

public class forgot extends AppCompatActivity{
    AutoCompleteTextView email;
    Button reset;
    LinearLayout current;
    View view;
    @Override
    public void onBackPressed() {
        startActivity(new Intent(forgot.this,LoginActivity.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot);
                getSupportActionBar().setDisplayHomeAsUpEnabled(true);
                getSupportActionBar().setDisplayShowHomeEnabled(true);
                getSupportActionBar().setTitle("Forgot Password");
                email=findViewById(R.id.email);
           /*     view = findViewById(R.id.nointernet);
                current = findViewById(R.id.layout1);
                BroadcastReceiver q = new as(this);
                IntentFilter filter = new IntentFilter();
                // specify the action to which receiver will listen
                filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
                registerReceiver(q, filter);*/
                reset=findViewById(R.id.email_sign_in_button);
                reset.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (email.getText().toString().length() > 0) {
                            FirebaseAuth.getInstance().sendPasswordResetEmail(email.getText().toString())
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                finish();
                                                Toast.makeText(forgot.this, "Reset link sent to email", Toast.LENGTH_LONG).show();
                                            } else {
                                                Toast.makeText(forgot.this, "Email is not registered yet.", Toast.LENGTH_LONG).show();
                                            }
                                        }
                                    });
                        }
                        else
                        {
                            Toast.makeText(forgot.this, "Enter the email", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
         /*   @Override
            public void connect() {
                current.setVisibility(View.VISIBLE);
                view.setVisibility(View.GONE);
            }

            @Override
            public void disconnect() {

                current.setVisibility(View.GONE);
                view.setVisibility(View.VISIBLE);

            }*/
            @Override
            public boolean onSupportNavigateUp() {
                onBackPressed();
                return true;
            }
        }







