package com.example.godseye;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager.widget.ViewPager;

import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.content.BroadcastReceiver;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.shimmer.ShimmerFrameLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import static java.util.Calendar.DAY_OF_MONTH;

public class Home extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerobj;
    private ActionBarDrawerToggle mtoggle;
    int count = 0, pos1;
    ArrayList<String> list1;
    TextView expected;
    ArrayList<String> images;
    LinearLayout sliderdotspanel;
    ViewPager viewPager;
    private int dotscount;
    private ImageView[] dots;
    int ec = 0,day=0,month=0,year=0,count1=0;
    String locationName;
    Spinner location;
    EditText date;
    String date1;
    Button datebtn1,analyse;
    GraphView graph1,graph2,graph3,graph4;
    Calendar c;
    DatePickerDialog dpd;
  //  View view;
   // LinearLayout current;
    ShimmerFrameLayout shimmerFrameLayout, shimmerFrameLayout1;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        shimmerFrameLayout1 = findViewById(R.id.parentShimmerLayout1);
   //     BroadcastReceiver q = new as(this);
    //    IntentFilter filter = new IntentFilter();
        // specify the action to which receiver will listen
      //  filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
       // registerReceiver(q, filter);
        //view = findViewById(R.id.nointernet);
        //current = findViewById(R.id.layout1);
        graph1=findViewById(R.id.graph1);
        graph2=findViewById(R.id.graph2);
        graph3=findViewById(R.id.graph3);
        graph4=findViewById(R.id.graph4);
        expected=findViewById(R.id.expected);
        date=findViewById(R.id.date);
        analyse=findViewById(R.id.analyse);
        drawerobj=findViewById(R.id.drawerlayout);
        datebtn1=findViewById(R.id.datebtn);
        location=findViewById(R.id.spinner);
        mtoggle=new ActionBarDrawerToggle(this,drawerobj,R.string.open,R.string.close);
        drawerobj.addDrawerListener(mtoggle);
        mtoggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        NavigationView navigationView=findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        shimmerFrameLayout1.startShimmerAnimation();
        FirebaseDatabase.getInstance().getReference().child("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot child : dataSnapshot.getChildren()) {
                    if (child.exists()) {
                        ec = ec + 1;
                    }
                }
                final TextView eventCount = (TextView) findViewById(R.id.Count);
                ValueAnimator animator = new ValueAnimator();
                animator.setObjectValues(0, ec);
                animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(ValueAnimator animation) {
eventCount.setText(String.valueOf(animation.getAnimatedValue())+"+");
                    }
                });
                animator.setEvaluator(new TypeEvaluator<Integer>() {
                    public Integer evaluate(float fraction, Integer startValue, Integer endValue) {
                        return Math.round(startValue + (endValue - startValue) * fraction);
                    }
                });
                animator.setDuration(2000);
                animator.start();
                final TextView workCount = (TextView) findViewById(R.id.Count1);
                ValueAnimator animator1 = new ValueAnimator();
                animator1.setObjectValues(0, 908);
                animator1.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                    public void onAnimationUpdate(ValueAnimator animation) {
                        workCount.setText(String.valueOf(animation.getAnimatedValue())+"+");
                    }
                });
                animator1.setEvaluator(new TypeEvaluator<Integer>() {
                    public Integer evaluate(float fraction, Integer startValue, Integer endValue) {
                        return Math.round(startValue + (endValue - startValue) * fraction);
                    }
                });
                animator1.setDuration(2000);
                animator1.start();
                shimmerFrameLayout1.stopShimmerAnimation();

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                shimmerFrameLayout1.stopShimmerAnimation();
            }
        });
         list1=new ArrayList<String>();
        FirebaseDatabase.getInstance().getReference().child("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
           for(DataSnapshot child: dataSnapshot.getChildren())
           {
               list1.add(child.getKey().toString());
           }

                locationName=list1.get(0);
                location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        locationName=list1.get(i);
               //         Toast.makeText(Home.this,locationName,Toast.LENGTH_LONG).show();
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(Home.this, R.layout.spinner_dropdown, list1);
              //  ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.layout.color_spinner);
               dataAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                location.setAdapter(dataAdapter);



            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
/*
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, list1);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        location.setAdapter(arrayAdapter);
        location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                 locationName = parent.getItemAtPosition(position).toString();
                 Toast.makeText(Home.this,locationName,Toast.LENGTH_LONG).show();
            }
            @Override
            public void onNothingSelected(AdapterView <?> parent) {
            }
        });
        */

      /*  try {
            LineGraphSeries < DataPoint > series = new LineGraphSeries < > (new DataPoint[] {
                    new DataPoint(0.2, 1.2),
                    new DataPoint(1.4, 2.2),
                    new DataPoint(2.1, 3.3),
                    new DataPoint(4.3, 5.4),
                    new DataPoint(6.5, 7.4)
            });
            graph1.setVisibility(View.VISIBLE);
            graph1.addSeries(series);
        } catch (IllegalArgumentException e) {
            Toast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG).show();
        }
*/


datebtn1.setOnClickListener(new View.OnClickListener()
{
    @Override
    public void onClick(View v) {

        if (locationName.isEmpty()) {
            Toast.makeText(Home.this, "Select the location first", Toast.LENGTH_LONG).show();
        } else {
            c = Calendar.getInstance();
            c.set(2019, 10, 1);
            day = c.get(Calendar.DAY_OF_MONTH);
            month = c.get(Calendar.MONTH);
            year = c.get(Calendar.YEAR);

            dpd = new DatePickerDialog(Home.this, new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int mYear, int mMonth, int mDay) {

                }
            }, day, month, year);
            dpd.show();
        }
    }
});

if(day!=0)
{
    if(month < 10){

                month = Integer.parseInt("0"+String.valueOf(month));
            }
            if(day < 10){

                day  = Integer.parseInt("0"+String.valueOf(day));
            }
}

analyse.setOnClickListener(new View.OnClickListener()
                           {
                               @Override
                               public void onClick(View v)
                               {
                                   date1=date.getText().toString();
                               count=0;
                               graph1.setVisibility(View.GONE);
                                   graph2.setVisibility(View.GONE);
                                   graph3.setVisibility(View.GONE);
                                   graph4.setVisibility(View.GONE);
                                   expected.setVisibility(View.GONE);
                                   if(locationName.isEmpty())
             {
                 Toast.makeText(Home.this, "Select the location first", Toast.LENGTH_LONG).show();
             shimmerFrameLayout.stopShimmerAnimation();
             }
             else if(date1.isEmpty())
             {
                 count=0;
                FirebaseDatabase.getInstance().getReference().child("location").child(locationName).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for(DataSnapshot child: dataSnapshot.getChildren())
                        {
                            if(child.exists())
                            {
                                String date = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
                                //String date="20-12-2019";
                                if(child.getKey().substring(3,5).equals(date.substring(3,5)) &&
                                        (child.getKey().substring(0,2).equals(String.valueOf(Integer.parseInt(date.substring(0,2))-1)) ||
                                                child.getKey().substring(0,2).equals(String.valueOf(Integer.parseInt(date.substring(0,2))-2))
                                                || child.getKey().substring(0,2).equals(String.valueOf(Integer.parseInt(date.substring(0,2))))))
                                {
                                    if(count==0)
                                    {
                                        try {
                                            LineGraphSeries <DataPoint> series = new LineGraphSeries< >();
                                            for(DataSnapshot child1: child.getChildren())
                                            {
                                                if(child1.exists())
                                                {
                                                    DataPoint d=new DataPoint(Float.parseFloat(child1.getKey().substring(0,2)+'.'+child1.getKey().substring(3,5)+child1.getKey().substring(6,8)),Float.parseFloat(child1.getValue().toString()));
                                                    series.appendData(d,true,100000);
                                                }
                                            }
                                            count=count+1;
                                            expected.setVisibility(View.VISIBLE);
                                            graph1.setVisibility(View.VISIBLE);
                                            graph1.setTitle(child.getKey());
                                            graph1.setContentDescription("TIME vs COUNT");
                                            graph1.addSeries(series);
                                        } catch (IllegalArgumentException e) {
                                            Toast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                    else if(count==1)
                                    {
                                        try {
                                            LineGraphSeries <DataPoint> series = new LineGraphSeries< >();
                                            for(DataSnapshot child1: child.getChildren())
                                            {
                                                if(child1.exists())
                                                {
                                                    DataPoint d=new DataPoint(Float.parseFloat(child1.getKey().substring(0,2)+'.'+child1.getKey().substring(3,5)+child1.getKey().substring(6,8)),Float.parseFloat(child1.getValue().toString()));
                                                    series.appendData(d,true,100000);
                                                }
                                            }
                                            count=count+1;
                                            graph2.setVisibility(View.VISIBLE);
                                            graph2.setTitle(child.getKey());
                                            graph2.addSeries(series);
                                        } catch (IllegalArgumentException e) {
                                            Toast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                    else if(count==2)
                                    {
                                        try {
                                            LineGraphSeries <DataPoint> series = new LineGraphSeries< >();
                                            for(DataSnapshot child1: child.getChildren())
                                            {
                                                if(child1.exists())
                                                {
                                                    DataPoint d=new DataPoint(Float.parseFloat(child1.getKey().substring(0,2)+'.'+child1.getKey().substring(3,5)+child1.getKey().substring(6,8)),Float.parseFloat(child1.getValue().toString()));
                                                    series.appendData(d,true,100000);
                                                }
                                            }
                                            count=count+1;
                                            graph3.setVisibility(View.VISIBLE);
                                            graph3.setTitle(child.getKey());
                                            graph3.addSeries(series);
                                        } catch (IllegalArgumentException e) {
                                            Toast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG).show();
                                        }
                                    }
                                }
                            }
                        }
                        if(count==0)
                        {
                            Toast.makeText(Home.this,"No previous data present",Toast.LENGTH_LONG).show();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
             }
             else
             {
                 graph1.setVisibility(View.GONE);
                 graph2.setVisibility(View.GONE);
                 graph3.setVisibility(View.GONE);
                 graph4.setVisibility(View.GONE);
                 expected.setVisibility(View.GONE);
                 FirebaseDatabase.getInstance().getReference().child("location").child(locationName).child(date1).addValueEventListener(new ValueEventListener() {
                     @Override
                     public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                         try {
                             LineGraphSeries <DataPoint> series = new LineGraphSeries< >();
                             for(DataSnapshot child: dataSnapshot.getChildren())
                             {
                                 if(child.exists())
                                 {
                                     DataPoint d=new DataPoint(Float.parseFloat(child.getKey().substring(0,2)+'.'+child.getKey().substring(3,5)+child.getKey().substring(6,8)),Float.parseFloat(child.getValue().toString()));
                                     series.appendData(d,true,100000);
                                 }
                             }
                             expected.setVisibility(View.VISIBLE);
                             //count=count+1;
                             graph4.setVisibility(View.VISIBLE);
                             graph4.setTitle(date1);
                             graph4.addSeries(series);
                         } catch (IllegalArgumentException e) {
                             Toast.makeText(Home.this, e.getMessage(), Toast.LENGTH_LONG).show();
                         }
                     }

                     @Override
                     public void onCancelled(@NonNull DatabaseError databaseError) {

                     }
                 });
             }
                               }
                           }
);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("General").child("News");
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                GenericTypeIndicator<List<String>> t = new GenericTypeIndicator<List<String>>() {};
                List<String> newsList = dataSnapshot.getValue(t);
                String finalNews="";
                if (newsList != null) {
                    for(Object temp:newsList)
                    {
                        finalNews=finalNews+" #"+(String)temp+" ";
                    }
                    TextView newsText=(TextView)findViewById(R.id.news);
                    newsText.setText(finalNews);
                    newsText.setSelected(true);
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {

            }
        });
        FirebaseDatabase.getInstance().getReference().child("General").child("homeslide").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                images=new ArrayList<String>();
                count=0;
                for (final DataSnapshot child : dataSnapshot.getChildren()) {
                    images.add(child.getValue().toString());
                    count=count+1;
                }

                dotscount=count;
                Log.d("dotscount", String.valueOf(dotscount));

                viewPager=findViewById(R.id.viewPager);
                viewPager.removeAllViews();
                sliderdotspanel=findViewById(R.id.Sliderdots);
                sliderdotspanel.removeAllViews();
                ViewPagerAdapter viewPagerAdapter=new ViewPagerAdapter(getApplicationContext(),images,count);
                viewPager.setAdapter(viewPagerAdapter);

                dots=new ImageView[dotscount];
                for(int i=0;i<dotscount;i++)
                {
                    dots[i]=new ImageView(Home.this);
                    dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.nonactive_dot));

                    LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,LinearLayout.LayoutParams.WRAP_CONTENT);
                    params.setMargins(0,0,5,0);
                    sliderdotspanel.addView(dots[i],params);
                }
                dots[0].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.active_dot));

                viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
                    @Override
                    public void onPageScrolled(int i, float v, int i1) {

                    }

                    @Override
                    public void onPageSelected(int pos) {
                        for(int i=0;i<dotscount;i++)
                        {
                            dots[i].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.nonactive_dot));
                        }
                        pos1=pos;
                        dots[pos].setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.active_dot));
                    }

                    @Override
                    public void onPageScrollStateChanged(int i) {

                    }
                });

                Timer timer=new Timer();
                timer.scheduleAtFixedRate(new MyTimerTask(dotscount,pos1),2000,3000);

            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
                //      load.dismiss();
            }
        });


    }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            // Inflate the menu; this adds items to the action bar if it is present.
            return true;
        }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(mtoggle.onOptionsItemSelected(item))
        {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

        @Override
        public boolean onNavigationItemSelected(MenuItem item) {
            // Handle navigation view item clicks here.
            int id = item.getItemId();
            if(id==R.id.about)
            {
                startActivity(new Intent(Home.this,about.class));
            }
            else if(id==R.id.logout)
            {
                AlertDialog.Builder builder= new AlertDialog.Builder(Home.this);
                builder.setCancelable(false)
                        .setIcon(R.drawable.out)
                        .setTitle("Confirm")
                        .setMessage("Sure to Logout??")
                        .setPositiveButton("LogOut", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                FirebaseAuth.getInstance().signOut();
                                startActivity(new Intent(Home.this,LoginActivity.class));

                            }
                        })
                        .setNegativeButton("Cancel",new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();
            }
            else if(id==R.id.profile)
            {
                startActivity(new Intent(Home.this,profile.class));
            }
            else if(id==R.id.predictor)
            {
                startActivity(new Intent(Home.this,predict.class));
            }

            return true;
        }

        @Override
        public void onPointerCaptureChanged(boolean hasCapture) {

        }
        @Override
        public void onBackPressed(){

        }
/*
        @Override
        public void connect() {
            current.setVisibility(View.VISIBLE);
            view.setVisibility(View.GONE);
            shimmerFrameLayout.setVisibility(View.VISIBLE);
        }

        @Override
        public void disconnect() {
            current.setVisibility(View.GONE);
            view.setVisibility(View.VISIBLE);
            shimmerFrameLayout.setVisibility(View.GONE);
        }

*/
public class MyTimerTask extends TimerTask
{
    int count,pos;
    MyTimerTask(int c,int p)
    {
        count=c;
        pos=p;
    }
    @Override
    public void run()
    {
        Home.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {

                if(viewPager.getCurrentItem()==0 && viewPager.getCurrentItem()!=count-1){
                    viewPager.setCurrentItem(1);
                }
                else if(viewPager.getCurrentItem()==1 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(2);
                }
                else if(viewPager.getCurrentItem()==2 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(3);
                }
                else if(viewPager.getCurrentItem()==3 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(4);
                }
                else if(viewPager.getCurrentItem()==4 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(5);
                }
                else if(viewPager.getCurrentItem()==5 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(6);
                }
                else if(viewPager.getCurrentItem()==6 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(7);
                }
                else if(viewPager.getCurrentItem()==7 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(8);
                }
                else if(viewPager.getCurrentItem()==8 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(9);
                }
                else if(viewPager.getCurrentItem()==9 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(10);
                }
                else if(viewPager.getCurrentItem()==10 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(11);
                }
                else if(viewPager.getCurrentItem()==11 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(12);
                }
                else if(viewPager.getCurrentItem()==12 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(13);
                }
                else if(viewPager.getCurrentItem()==13 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(14);
                }
                else if(viewPager.getCurrentItem()==14 && viewPager.getCurrentItem()!=count-1)
                {
                    viewPager.setCurrentItem(15);
                }
                else
                {
                    viewPager.setCurrentItem(0);
                }
            }
        });
    }
}

    }
