package com.example.godseye;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Register extends AppCompatActivity {
    AutoCompleteTextView name,email,contact,contact1;
    int flag=0;
    EditText password,confirmpass;
    Button submit;
    LinearLayout current;
    View view;

    @Override
    public void onBackPressed() {
        startActivity(new Intent(Register.this,LoginActivity.class));
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);
        getSupportActionBar().setTitle("Register");;
        view = findViewById(R.id.nointernet);
        current = findViewById(R.id.layout1);
      /*  BroadcastReceiver q = new as(this);
        IntentFilter filter = new IntentFilter();
        // specify the action to which receiver will listen
        filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
        registerReceiver(q, filter);*/
        name=findViewById(R.id.name);
        email=findViewById(R.id.email);
        contact=findViewById(R.id.phoneno);
        contact1=findViewById(R.id.phoneno1);
        password=findViewById(R.id.password);
        confirmpass=findViewById(R.id.confirmpassword);
        submit=findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v)
            {
                //load.show();
                String email1="",name1="",phoneno1="",phoneno2="",p1="",p2="";
                name1=name.getText().toString();
                phoneno1=contact.getText().toString();
                phoneno2=contact1.getText().toString();
                email1=email.getText().toString();
                p1= password.getText().toString();
                p2=confirmpass.getText().toString();
                String passcode="",confirmpasscode="";
                passcode=password.getText().toString();
                confirmpasscode=confirmpass.getText().toString();
                if(name1.isEmpty()  || email1.isEmpty()|| phoneno1.isEmpty()||phoneno2.isEmpty() || p1.isEmpty() || p2.isEmpty())
                {
                    //load.dismiss();
                    Toast.makeText(Register.this,"Enter all the fields.",Toast.LENGTH_LONG).show();
                    return;
                }
                else if(phoneno1.length() != 10)
                {
                    //load.dismiss();
                    Toast.makeText(Register.this, "Mobile No. must have 10 digits", Toast.LENGTH_LONG).show();
                    return;
                }
                else if(!phoneno2.equals("") && phoneno2.length() != 10)
                {
                    //load.dismiss();
                    Toast.makeText(Register.this, " Alternate Mobile No. must have 10 digits", Toast.LENGTH_LONG).show();
                    return;
                }
                else if(!phoneno2.equals("") && phoneno2.equals(phoneno1) )
                {
                    //load.dismiss();
                    Toast.makeText(Register.this, " Alternate Mobile No. is same as primary mobile number", Toast.LENGTH_LONG).show();
                    return;
                }
                //emailid1=email.getText().toString();
                else if(!passcode.equals(confirmpasscode))
                {
                    //  load.dismiss();
                    Toast.makeText(Register.this,"PASSWORDS do not match",Toast.LENGTH_LONG).show();
                    return;
                }
                else if(passcode.length()<8) {
                    //load.dismiss();
                    Toast.makeText(Register.this, "Password should contain atleast 8 characters.", Toast.LENGTH_LONG).show();
                    return;
                }
                    final String finalName = name1;
                    final String finalEmail = email1;
                    final String finalPhoneno = phoneno1;
                    final String finalPhoneno1 = phoneno2;
                    DatabaseReference db= FirebaseDatabase.getInstance().getReference().child("Users");
                    Query query = db.orderByKey().limitToLast(1);
                    final String finalPasscode = passcode;
                            FirebaseAuth.getInstance().createUserWithEmailAndPassword(finalEmail, finalPasscode).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Users").child(FirebaseAuth.getInstance().getUid());
                                        ref.child("name").setValue(finalName);
                                        ref.child("email").setValue(finalEmail);
                                        ref.child("contact").setValue(finalPhoneno);
                                        ref.child("optcontact").setValue(finalPhoneno1);
                                        FirebaseAuth.getInstance().signOut();
                                        //  load.dismiss();
                                        Toast.makeText(Register.this, "ACCOUNT CREATION SUCCESSFULL.", Toast.LENGTH_LONG).show();
                                        startActivity(new Intent(Register.this, LoginActivity.class));
                                    } else {
                                        //load.dismiss();
                                        Toast.makeText(Register.this, "Email already registered.", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });







            }
        });




    }
   /* @Override
    public void connect() {
        current.setVisibility(View.VISIBLE);
        view.setVisibility(View.GONE);
    }

    @Override
    public void disconnect() {

        current.setVisibility(View.GONE);
        view.setVisibility(View.VISIBLE);

    }*/
}
