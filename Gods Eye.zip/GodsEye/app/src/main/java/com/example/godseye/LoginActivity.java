package com.example.godseye;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {
    AutoCompleteTextView email;
    EditText password;
    Button login;
    TextView signup,forgot;
    boolean isConnected=false;
    LinearLayout current;
    View view;
    @Override
    public void onBackPressed() {
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
            //    current=findViewById(R.id.layout1);
             //   view = findViewById(R.id.nointernet);
                email=findViewById(R.id.email);
                password=findViewById(R.id.password);
                login=findViewById(R.id.login);
                signup=findViewById(R.id.signup);
                forgot=findViewById(R.id.forgot);
             //   BroadcastReceiver q = new as(this);
              //  IntentFilter filter = new IntentFilter();
                // specify the action to which receiver will listen
              //  filter.addAction("android.net.conn.CONNECTIVITY_CHANGE");
               // registerReceiver(q, filter);
                forgot.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(LoginActivity.this,forgot.class));
                    }
                });
                login.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        // progressBar.setVisibility(View.VISIBLE);
                        String emailid = "", passcode = "";
                        emailid = email.getText().toString();
                        passcode = password.getText().toString();
                        if (emailid.isEmpty() || passcode.isEmpty()) {
                            // progressBar.setVisibility(View.GONE);
                            Toast.makeText(LoginActivity.this, "Enter both the email and password.", Toast.LENGTH_LONG).show();
                        }
                        else
                        {
                            final ProgressBar spin = (ProgressBar) findViewById(R.id.progressBar);
                            spin.setVisibility(View.VISIBLE);
                            FirebaseAuth.getInstance().signInWithEmailAndPassword(emailid, passcode).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        spin.setVisibility(View.GONE);
                                        startActivity(new Intent(LoginActivity.this, Home.class));
                                    } else {
                                        //progressBar.setVisibility(View.GONE);
                                        spin.setVisibility(View.GONE);
                                        Toast.makeText(LoginActivity.this, "EMAIL or PASSWORD is incorrect", Toast.LENGTH_LONG).show();
                                    }
                                }
                            });
                        }

                    }
                });
                signup.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        startActivity(new Intent(LoginActivity.this, Register.class));
                    }
                });
            }
    /*        @Override
            public void connect() {
                current.setVisibility(View.VISIBLE);
                view.setVisibility(View.GONE);
            }

            @Override
            public void disconnect() {

                current.setVisibility(View.GONE);
                view.setVisibility(View.VISIBLE);

            }*/



        }






