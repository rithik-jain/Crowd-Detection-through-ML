package com.example.godseye;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class predict extends AppCompatActivity {
EditText time,date;
TextView predict1;
Spinner location;
int comp;
Button predict;
String locationName;
    ArrayList<String> list1;
    ArrayList<Double> x1,y1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict);
        predict=findViewById(R.id.pred);
        location=findViewById(R.id.spinner);
        time=findViewById(R.id.time);
        date=findViewById(R.id.date);
        predict1=findViewById(R.id.expected);
       list1=new ArrayList<String>();
        FirebaseDatabase.getInstance().getReference().child("location").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for(DataSnapshot child: dataSnapshot.getChildren())
                {
                    list1.add(child.getKey().toString());
                }

                locationName=list1.get(0);
                location.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        locationName=list1.get(i);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
                ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(predict.this, android.R.layout.simple_dropdown_item_1line, list1);
                dataAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
                location.setAdapter(dataAdapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        predict.setOnClickListener(new View.OnClickListener()
                                   {
                                       @Override
                                       public void onClick(View v)
                                       {
                                           final String date1=date.getText().toString();
                                           final String time1=time.getText().toString();
                                           comp=dayofweek(Integer.parseInt(date1.substring(0,2)), Integer.parseInt(date1.substring(3,5)), Integer.parseInt(date1.substring(6,10)));
                                           //Toast.makeText(predict.this,String.valueOf(comp),Toast.LENGTH_LONG).show();
                                           if(locationName.isEmpty() || date1.isEmpty() || time1.isEmpty())
                                           {
                                               Toast.makeText(predict.this,"Fill out all fields",Toast.LENGTH_LONG).show();
                                           }
                                           else
                                           {
                                               x1=new ArrayList<Double>();
                                               y1=new ArrayList<Double>();
                                               FirebaseDatabase.getInstance().getReference().child("location").child(locationName).addValueEventListener(new ValueEventListener() {
                                                   @Override
                                                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                       for (DataSnapshot child: dataSnapshot.getChildren())
                                                       {
                                                           if(child.exists() && !child.getKey().equals("limit"))
                                                           {
                                                               if(comp == dayofweek(Integer.parseInt(child.getKey().substring(0,2)), Integer.parseInt(child.getKey().substring(3,5)), Integer.parseInt(child.getKey().substring(6,10))));
                                                               {
                                                                    for(DataSnapshot child1:child.getChildren())
                                                                    {
                                                                    if(child1.exists())
                                                                    {
                                                                        x1.add(Double.parseDouble(child1.getKey().substring(0,2)+'.'+child1.getKey().substring(3,5)));
                                                                        y1.add(Double.parseDouble(child1.getValue().toString()));
                                                                       // Toast.makeText(predict.this,"I amhere",Toast.LENGTH_LONG).show();
                                                                    }


                                                                    }
                                                               }
                                                           }
                                                       }
                                                       double a[]=new double[x1.size()];
                                                       double b[]=new double[y1.size()];
                                                       for(int i=0;i<x1.size();i++)
                                                       {
                                                           a[i]=x1.get(i);
                                                           b[i]=y1.get(i);
                                                       }

                                                       LinearRegression linearRegression = new LinearRegression(a,b);
                                                       double result;
                                                       result=linearRegression.predict(Double.parseDouble(time1.substring(0,2)+'.'+time1.substring(3,5)));
                                                       predict1.setText("The expected crowd is: "+String.valueOf(result));
                                                   }

                                                   @Override
                                                   public void onCancelled(@NonNull DatabaseError databaseError) {

                                                   }
                                               });
                                               //Toast.makeText(predict.this,String.valueOf(x1.size()),Toast.LENGTH_LONG).show();

                                           }
                                       }
                                   }
        );


}


    static int dayofweek(int d, int m, int y)
    {
        int t[] = { 0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4 };
        y -= (m < 3) ? 1 : 0;
        return ( y + y/4 - y/100 + y/400 + t[m-1] + d) % 7;
    }
public void onBackPressed()
{
    startActivity(new Intent(predict.this,Home.class));
}
}
